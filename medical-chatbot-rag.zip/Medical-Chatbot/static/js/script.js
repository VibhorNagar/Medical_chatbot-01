const chat = document.getElementById('chat');
const form = document.getElementById('chat-form');
const input = document.getElementById('msg');
const sendBtn = document.getElementById('send');

function addMessage(text, who, cls = '', pages = []) {
  const row = document.createElement('div');
  row.className = 'msg ' + who;
  const bubble = document.createElement('div');
  bubble.className = 'bubble ' + cls;
  bubble.textContent = text;                      // textContent: no HTML injection
  if (pages.length) {
    const s = document.createElement('span');
    s.className = 'src';
    s.textContent = 'Source: PDF page' + (pages.length > 1 ? 's ' : ' ') + pages.join(', ');
    bubble.appendChild(s);
  }
  row.appendChild(bubble);
  chat.appendChild(row);
  chat.scrollTop = chat.scrollHeight;
  return row;
}

addMessage('Hi! I am a medical information bot. Try: "What is acromegaly and gigantism?"', 'bot');

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  const text = input.value.trim();
  if (!text) return;
  input.value = '';
  addMessage(text, 'user');
  const typing = addMessage('Searching the book…', 'bot', 'typing');
  sendBtn.disabled = true;
  try {
    const res = await fetch('/get', { method: 'POST', body: new URLSearchParams({ msg: text }) });
    const data = await res.json();
    typing.remove();
    if (!res.ok) addMessage(data.error || 'Something went wrong.', 'bot', 'error');
    else addMessage(data.answer, 'bot', '', data.pages || []);
  } catch (err) {
    typing.remove();
    addMessage('Could not reach the server. Is it running?', 'bot', 'error');
  } finally {
    sendBtn.disabled = false;
    input.focus();
  }
});
